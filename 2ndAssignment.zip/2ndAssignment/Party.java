import java.util.*;
import model.*;
public class Party {
		
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Mufasa mufasa = new Mufasa();
		Rafiki rafiki = new Rafiki();
		Zazu zazu = new Zazu();
		String userCommand;
		
		do{
			System.out.println("-------------------------------");
			System.out.println("1-Add a new guest.");
			System.out.println("2-Remove one guest.");
			System.out.println("3-sort songs.");
			System.out.println("4-List all played songs.");
			System.out.println("5-Check if an animal is on the Guest list.");
			System.out.println("6-List all needs by their names.");
			System.out.println("7-List all needs by their species.");
			System.out.println("8-Exit.");
			System.out.println("-------------------------------");
			userCommand = scanner.next();
			switch (userCommand) {
				case "1":
					System.out.println("What is new guest's name?");
					String name = scanner.next();
					System.out.println("What is new guest's Specie?");
					String specie = scanner.next();
					System.out.println("What song did new guest promote?");
					String song = scanner.next();
					System.out.println("What needs do new guest need?");
					String need = scanner.next();
					for(int i=0;i<Init.getGuestList().size();i++){
						if(Init.getGuestList().get(i).getSpecie().equals(specie)){
							need = Init.getGuestList().get(i).getNeeds();
							break;
						}
					}
					mufasa.addNewGuest(name, specie, song, need);
					zazu.addMusic(song);
					
					break;
				case "2":
					System.out.println("Which guest do you want to remove?");
					String tname = scanner.next();
					mufasa.removeGuest(tname);
					break;
				case "3":
					for(String s:Init.getSongList()){
						Init.getPlayedSongList().add(s);
					}
					Collections.sort(Init.getSongList());
					System.out.println("Song list has been sorted.");
					break;
				case "4":
					System.out.println(Init.getPlayedSongList().toString());
					break;
				case "5":
					System.out.println("Which guest do you want to check?");
					String tname2 = scanner.next();
					if(mufasa.isGuestExist(tname2))
						System.out.println(tname2+ " is exist in guest list.");
					else 
						System.out.println(tname2+" is not exist in guest list.");
					break;	
				case "6":
					Collections.sort(Init.getGuestList(), Animal.NameComparator);
					System.out.println("Name     Need");
					for(int i = 0;i<Init.getGuestList().size();i++){
						System.out.println(Init.getGuestList().get(i).getName()+ "     "+Init.getGuestList().get(i).getNeeds());
					}
					break;
				case "7":
					Collections.sort(Init.getGuestList(), Animal.SpecieComparator);
					System.out.println("Specie     Need");
					for(int i = 0;i<Init.getGuestList().size();i++){
					System.out.println(Init.getGuestList().get(i).getSpecie()+ 	"     "+Init.getGuestList().get(i).getNeeds());
					}
					break;							
				default:
				
					break;
			}
			
		}while(!userCommand.equals("8"));
		
		
	}
}