package model;
import java.util.*;
public class Rafiki{
	public Rafiki(){

	}
	//		Check if a guest is allowed by its name
	//		Check which are the needs by animal name (e.g. Simba) or specie name (e.g. Lion)
	public Boolean isAllowed(String name){
		Boolean isA=false;
		ArrayList<Animal> list = Init.getGuestList();
		for(int i=0;i<list.size();i++){
			if(list.get(i).getName().equals(name)){
				isA = true;
				break;
			}
		}
		return isA;
	}
	public String getAnimalNeeds(String name){
		String output=null;
		ArrayList<Animal> list = Init.getGuestList();
		for(int i=0;i<list.size();i++){
			if(list.get(i).getName().equals(name)){
				output=list.get(i).getNeeds();
				break;
			}
		}
		return output;
	}
}