package model;
import java.util.*;
public class Zazu{
	public Zazu(){
	}
	public void addMusic(String song){
		ArrayList<String> songList= Init.getSongList();
		if(!checkExist(song)){
			songList.add(song);
		}
	}
	public boolean checkExist(String song){
		boolean isExist = false;
		ArrayList<String> songList= Init.getSongList();
		for(String s : songList){
			if(s.equals(song)){
				System.out.println(song+" is already exsit.");
				isExist=true;
				break;
			}
		}
		return isExist;
	}
}