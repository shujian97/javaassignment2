package model;
import java.util.*;

public class Animal{
	private String name;
	private String specie;
	private String song;
	private String needs;
	public Animal(){}
	public Animal(String name,String specie,String song,String needs){
		this.name = name;
		this.specie = specie;
		this.song = song;
		this.needs = needs;
	}
	public void setName(String name){
		this.name = name;
	}
	public void setSpecie(String specie){
		this.specie = specie;
	}
	public void setSong(String song){
		this.song = song;
	}
	public void setNeeds(String needs){
		this.needs = needs;
	}
	public String getName(){
		return this.name;
	}
	public String getSpecie(){
		return this.specie;
	}
	public String getSong(){
		return this.song;
	}
	public String getNeeds(){
		return this.needs;
	}
	public String toString(){
		return this.name + " " +this.specie+" "+this.song+" "+this.needs;
	}
	public static Comparator<Animal> NameComparator = new Comparator<Animal>() {

		public int compare(Animal s1, Animal s2) {
		   String AnimalName1 = s1.getName().toUpperCase();
		   String AnimalName2 = s2.getName().toUpperCase();

		   return AnimalName1.compareTo(AnimalName2);

	   	}};
	public static Comparator<Animal> SpecieComparator = new Comparator<Animal>() {

			public int compare(Animal s1, Animal s2) {
			   String AnimalName1 = s1.getSpecie().toUpperCase();
			   String AnimalName2 = s2.getSpecie().toUpperCase();

			   return AnimalName1.compareTo(AnimalName2);

		   	}};
}