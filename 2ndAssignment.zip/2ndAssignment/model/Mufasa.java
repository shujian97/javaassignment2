package model;
import java.util.*;
public class Mufasa{
	public Mufasa(){
		
	}
	public void addNewGuest(String name,String specie,String song,String need){
		boolean isExist = false;
		ArrayList<Animal> guestList = Init.getGuestList();
		for(Animal a:guestList){
			if(a.getName().equals(name.toUpperCase())){
				isExist=true;
				break;
			}
		}
		if(isExist==true){
			System.out.println("--Notice:");
			System.out.println(name+" is already exist in guest list.");
			System.out.println(" ");
		}else{
			for(Animal a : guestList){
				if(a.getSpecie().equals(specie.toUpperCase())){
					need = a.getNeeds();
					break;
				}
			}
			Animal a = new Animal(name.toUpperCase(),specie.toUpperCase(),song.toUpperCase(),need.toUpperCase());
			guestList.add(a);
		}
	}
	public void removeGuest(String name){
		boolean isExist = false;
		ArrayList<Animal> guestList = Init.getGuestList();
		Animal b = new Animal();
		for(Animal a:guestList){
			if(a.getName().equals(name.toUpperCase())){
				b = a;
				isExist=true;
				break;
			}
		}
		if(isExist==true){
			guestList.remove(b);
		}else{
			System.out.println(name+" is not exist in guest list.");
		}
	}
	public boolean isGuestExist(String name){
		ArrayList<Animal> guestList = Init.getGuestList();
		for(Animal a:guestList){
			if(a.getName().equals(name.toUpperCase())){
				return true;
			}
		}
		return false;
	}
}