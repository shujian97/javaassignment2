package model;
import java.util.*;
public class Flying extends Animal{
	private String arravingMode = 'Flying';
	public Flying(){
		
	}
	public Flying(String name,String specie,String song){
		this.name = name;
		this.specie = specie;
		this.song = song;
	}
}