package model;
import java.util.*;
public class Init {
	private static ArrayList<Animal> guestList = new ArrayList<Animal>();
	private static ArrayList<String> songList = new ArrayList<String>();
	private static Map<String,String> needList= new HashMap<String,String>();
	private static ArrayList<String> playedSongList= new ArrayList<String>();
	public static ArrayList<Animal> getGuestList(){
		return guestList;
	}
	public static Map<String,String> getNeedList(){
		return needList;
	}
	public static ArrayList<String> getSongList(){
		return songList;
	}
	public static ArrayList<String> getPlayedSongList(){
		return playedSongList;
	}

}