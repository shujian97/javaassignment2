package model;
import java.util.*;
public class Swimming extends Animal{
	private String arravingMode = 'Swimming';
	public Swimming(){
		
	}
	public Swimming(String name,String specie,String song){
		this.name = name;
		this.specie = specie;
		this.song = song;
	}
}