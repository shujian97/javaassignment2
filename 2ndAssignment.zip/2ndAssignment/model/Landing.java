package model;
import java.util.*;
public class Landing extends Animal{
	private String arravingMode = 'Landing';
	public Landing(){
		
	}
	public Landing(String name,String specie,String song){
		this.name = name;
		this.specie = specie;
		this.song = song;
	}
}